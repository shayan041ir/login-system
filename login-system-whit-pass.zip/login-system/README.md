
step 1:
composer install
php artisan key:generate
step 2:
php artisan migrate

step 3:
php artisan serve

step4:
php artisan queue:work