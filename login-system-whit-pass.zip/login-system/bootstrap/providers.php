<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\OtpServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
];
